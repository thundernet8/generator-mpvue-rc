## 说明

** src/components ** 文件夹为 mpvue 编写的组件源代码
** mp/components ** 文件夹为编译输出的原生小程序自定义组件
** mp ** 文件夹为预览组件使用的小程序原生代码

## 使用

```js
npm run dev
```

```js
npm run build
```

## 预览

打开微信小程序开发者工具，打开本项目根目录导入小程序项目，预览组件
