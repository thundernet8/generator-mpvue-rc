Page({
    data: {
        title: 'world'
    },

    onLoad() {
        console.log('Index page loaded');
    }
});
