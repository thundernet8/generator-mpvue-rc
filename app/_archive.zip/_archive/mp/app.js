App({
    onLaunch() {
        console.log('App launched');
    }
});
