require('../common/common.js');
global.webpackJsonp([0],{

/***/ "2N8q":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_rc_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__("uLJx");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_vue__ = __webpack_require__("5nAL");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_mpvue_rc_loader_lib_template_compiler_index_id_data_v_26bbdd82_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_node_modules_mpvue_rc_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__("nlAU");
function injectStyle (ssrContext) {
  __webpack_require__("9zHm")
}
var normalizeComponent = __webpack_require__("D3hA")
/* script */


    __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_rc_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */].mpType = 'component';
    new __WEBPACK_IMPORTED_MODULE_1_vue___default.a(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_rc_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */]).$mount();/* template */

/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-26bbdd82"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_rc_loader_lib_selector_type_script_index_0_index_vue__["a" /* default */],
  __WEBPACK_IMPORTED_MODULE_2__node_modules_mpvue_rc_loader_lib_template_compiler_index_id_data_v_26bbdd82_hasScoped_true_transformToRequire_video_src_source_src_img_src_image_xlink_href_node_modules_mpvue_rc_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),

/***/ "2zIM":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["a"] = ({
    props: ['text']
});

/***/ }),

/***/ "9zHm":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "UCfo":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_rc_loader_lib_selector_type_script_index_0_card_vue__ = __webpack_require__("2zIM");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_rc_loader_lib_template_compiler_index_id_data_v_36dd09bd_hasScoped_false_transformToRequire_video_src_source_src_img_src_image_xlink_href_node_modules_mpvue_rc_loader_lib_selector_type_template_index_0_card_vue__ = __webpack_require__("d2Jw");
function injectStyle (ssrContext) {
  __webpack_require__("oM30")
}
var normalizeComponent = __webpack_require__("D3hA")
/* script */

/* template */

/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_mpvue_rc_loader_lib_selector_type_script_index_0_card_vue__["a" /* default */],
  __WEBPACK_IMPORTED_MODULE_1__node_modules_mpvue_rc_loader_lib_template_compiler_index_id_data_v_36dd09bd_hasScoped_false_transformToRequire_video_src_source_src_img_src_image_xlink_href_node_modules_mpvue_rc_loader_lib_selector_type_template_index_0_card_vue__["a" /* default */],
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ __webpack_exports__["a"] = (Component.exports);


/***/ }),

/***/ "d2Jw":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('p', {
    staticClass: "card"
  }, [_vm._v("A card")]), _vm._v(" "), _vm._t("default", null, {
    mpcomid: '0'
  })], 2)
}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "nlAU":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "container"
  }, [_c('div', {
    staticClass: "title"
  }, [_vm._v(_vm._s(_vm.title))]), _vm._v(" "), _c('card', {
    attrs: {
      "mpcomid": '0'
    }
  }, [_c('p', [_vm._v("node rendered in slot")])], 1)], 1)
}
var staticRenderFns = []
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);

/***/ }),

/***/ "oM30":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "uLJx":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__card_vue__ = __webpack_require__("UCfo");
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["a"] = ({
    components: { card: __WEBPACK_IMPORTED_MODULE_0__card_vue__["a" /* default */] },

    props: {
        words: {
            type: String,
            required: true,
            default: 'unknown'
        }
    },

    data() {
        return {
            hello: 'hello'
        };
    },

    computed: {
        title() {
            return `${this.hello} ${this.words}`;
        }
    }
});

/***/ })

},["2N8q"]);